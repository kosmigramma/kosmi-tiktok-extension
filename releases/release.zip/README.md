# kosmi-tiktok-extension

A chrome extension to spoof a mobile device and simplify tiktok ui
